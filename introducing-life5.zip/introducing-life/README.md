# introducing.life

The agentic internet, profiled daily.

## Deploy in 10 minutes

## Local preview

To run locally on Windows without thinking about PATH setup:

```powershell
.\run-local.ps1
```

Open:

```text
http://127.0.0.1:5173
```

Local `npm run dev` now serves `/api/analyze` and `/api/market-scan` through Vite middleware, so the builder tools and market scan also work in local development.

You do not need an Anthropic key just to browse the interface.
Without the key, pages still load normally, but AI generation actions will not return results.

### 1. Put this on GitHub

Create a new repo at `github.com/new` called `introducing-life`, then:

```bash
git init
git add .
git commit -m "init"
git remote add origin https://github.com/YOUR_USERNAME/introducing-life.git
git push -u origin main
```

### 2. Deploy to Vercel

1. Go to Vercel -> New Project
2. Import your `introducing-life` GitHub repo
3. Vercel auto-detects Vite
4. Deploy

### 3. Connect introducing.life

In your Vercel project, add the `introducing.life` domain.

DNS records:
- `A` -> `@` -> `76.76.21.21`
- `CNAME` -> `www` -> `cname.vercel-dns.com`

### 4. Set up the API key

The Analyze tab now uses a server-side endpoint at `/api/analyze`.

Create a local env file:

```bash
cp .env.example .env
```

Set:

```bash
ANTHROPIC_API_KEY=your_anthropic_key_here
OPENAI_API_KEY=
GOOGLE_API_KEY=
XAI_API_KEY=
SUPABASE_URL=
SUPABASE_SERVICE_ROLE_KEY=
RATE_LIMIT_WINDOW_MS=60000
RATE_LIMIT_MAX_REQUESTS=10
ALLOWED_ORIGINS=http://127.0.0.1:5173
```

In Vercel, add the same `ANTHROPIC_API_KEY` in Project Settings -> Environment Variables.
For production, also set `ALLOWED_ORIGINS` to your real domains, comma-separated.

## Security baseline

- Anthropic key is server-side only
- The browser no longer calls Anthropic directly
- Model output is normalized before entering storage
- `vercel.json` adds baseline security headers
- `vite` is upgraded to a patched line
- Analyze endpoint enforces content type, origin checks, and rate limits
- CI runs build plus `npm audit --omit=dev` on every push and pull request

## Providers

The app now supports multiple model backends:

- Anthropic
- OpenAI
- Google
- Grok / xAI
- Ollama

Cloud providers are called server-side and use env vars.
Ollama is configured client-side so a user can point the UI at a local or home-hosted Ollama server.

For local Ollama on the same machine, the default base URL is:

```text
http://127.0.0.1:11434
```

For a home-hosted Ollama server on the LAN, point the app to:

```text
http://YOUR_LAN_IP:11434
```

Recommended local-model settings for better schema stability:

- `temperature`: `0.2`
- `num_predict`: `700`

Use the `Test connection` button in the UI to query `/api/tags` and load the models available on that Ollama instance.

## Market scan

The old `Rate the Hype` lane is now a market scan surface instead of an LLM-only verdict.

`Bull` now:

- classifies the idea category
- builds search queries from the input
- searches public sources aligned to that category
- compares the idea against existing projects and recent discussion
- returns an `Introducing Index` based on innovation, trend, saturation, and evidence

Current public-source coverage includes:

- GitHub
- Hacker News
- Reddit
- npm
- CoinGecko for token/memecoin lanes
- DexScreener for token and pair discovery
- arXiv for research and agent/reasoning lanes
- Hugging Face for model and agent ecosystem scans

This path is intentionally cheaper and more explainable than using a model just to decide whether something is trend-driven, crowded, or meaningfully new.

## Current audit status

- Production dependencies: clean
- Dev dependencies: one moderate advisory remains through `esbuild` in the Vite toolchain
- Current mitigation: dev server bound to `127.0.0.1` in `vite.config.js`

## Shared archive and submissions

Phase 1 now includes server routes for:

- `GET /api/entries`
- `POST /api/entries`
- `GET /api/submissions`
- `POST /api/submissions`
- `PATCH /api/submissions`

If `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` are configured, the site uses a shared global archive and a shared submission queue.

If they are not configured, the app falls back to seed/local data so local development still works.

In no-cost mode, the homepage still gets a deterministic `daily auto-featured` pick, so the digest behavior can be developed and demoed before any paid/shared infrastructure decision.
The `review` lane also works in local/mock mode, so submissions can be promoted into the archive without external infrastructure.
The review queue can also `Promote + feature today`, which stores a local digest schedule for the current day and makes the homepage behave like a live editorial front page.
The `monitor` lane simulates autonomous source discovery and can push mocked source items into the review queue, which gives you a full no-cost demo of the future ingestion loop.
Batch 4 starts replacing that with real free-source collection through `/api/monitor`, currently using:

- GitHub repository search
- Hacker News recent stories
- Reddit search

If those sources fail or return nothing useful in local development, the UI falls back to the mock sweep so the product flow still works end to end.
The collector now also deduplicates overlapping candidates and applies an editorial ranking layer before sending items to the monitor UI.
Each sweep is now saved locally as a monitor snapshot, so you can compare ingestion states across days and re-open previous sweep results.

## Builder workspace

Batch 2 begins with a persistent local workspace for the builder toolkit:

- `launch` generations are saved locally as reusable artifacts
- `gut-check` generations are saved locally as reusable artifacts
- previous artifacts can be reloaded into the UI for iteration

This keeps the HOW lane useful before auth, billing, or shared builder accounts are introduced.

## Market intelligence workspace

Batch 3 extends the `Bull` lane into a recurring intelligence surface:

- market scans are saved locally as reusable reports
- scans can be reloaded for comparison and iteration
- high-interest ideas can be added to a local watchlist

This turns the market scan into an ongoing research surface instead of a one-off query.

To enable the shared database:

1. Create a Supabase project
2. Run [schema.sql](/c:/Users/loure/OneDrive/Área%20de%20Trabalho/Projetos/Gui/introducing-life/introducing-life/supabase/schema.sql)
3. Add `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` to local `.env`
4. Add the same variables to Vercel

Tables created by the schema:

- `entries`
- `submissions`
- `daily_features`

## Roadmap

- [ ] Shared Supabase database
- [x] Server-side API key via Vercel Function
- [ ] Submit form so builders can submit their own launches
- [ ] Daily email digest
- [ ] X/Twitter monitoring via API or RSS
- [ ] GitHub Trending scraper
- [ ] Product Hunt feed integration
- [ ] One featured pick per day, auto-selected by novelty score
- [ ] Source adapters for X, Farcaster, and niche market feeds
- [ ] Persisted market-scan history and saved watchlists
