create extension if not exists pgcrypto;

create table if not exists public.entries (
  id uuid primary key default gen_random_uuid(),
  date timestamptz not null default now(),
  project_name text not null,
  one_liner text not null,
  what_it_does text not null,
  who_built_it text not null default 'Unknown',
  category text not null default 'other',
  tech_stack text[] not null default '{}',
  novelty_score integer not null default 0,
  novelty_verdict text not null default 'Solid Execution',
  novelty_reasoning text not null default '',
  hook text not null default '',
  missing text not null default '',
  editorial_note text not null default ''
);

create index if not exists entries_date_idx on public.entries (date desc);
create index if not exists entries_category_idx on public.entries (category);

create table if not exists public.submissions (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  project_name text not null,
  project_url text not null default '',
  contact text not null default '',
  category_hint text not null default '',
  summary text not null,
  status text not null default 'new',
  notes text not null default ''
);

create index if not exists submissions_created_at_idx on public.submissions (created_at desc);
create index if not exists submissions_status_idx on public.submissions (status);

create table if not exists public.daily_features (
  id uuid primary key default gen_random_uuid(),
  feature_date date not null unique,
  entry_id uuid not null references public.entries(id) on delete cascade,
  created_at timestamptz not null default now()
);

create index if not exists daily_features_feature_date_idx on public.daily_features (feature_date desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists submissions_set_updated_at on public.submissions;
create trigger submissions_set_updated_at
before update on public.submissions
for each row
execute procedure public.set_updated_at();
